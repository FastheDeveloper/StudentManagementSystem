-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2020 at 02:04 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `plustwo1`
--

CREATE TABLE IF NOT EXISTS `plustwo1` (
  `RollNo` int(1) DEFAULT NULL,
  `SubName` varchar(27) DEFAULT NULL,
  `SubCode` int(3) DEFAULT NULL,
  `Internal` int(1) DEFAULT NULL,
  `Theory` int(1) DEFAULT NULL,
  `Practical` int(1) DEFAULT NULL,
  `Total` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `plustwo1`
--

INSERT INTO `plustwo1` (`RollNo`, `SubName`, `SubCode`, `Internal`, `Theory`, `Practical`, `Total`) VALUES
(3, 'Object oriented programming', 306, 5, 4, 4, 13);

-- --------------------------------------------------------

--
-- Table structure for table `plustwo2`
--

CREATE TABLE IF NOT EXISTS `plustwo2` (
  `RollNo` int(1) DEFAULT NULL,
  `SubName` varchar(21) DEFAULT NULL,
  `SubCode` int(3) DEFAULT NULL,
  `Internal` int(1) DEFAULT NULL,
  `Theory` int(1) DEFAULT NULL,
  `Practical` int(1) DEFAULT NULL,
  `Total` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `plustwo2`
--

INSERT INTO `plustwo2` (`RollNo`, `SubName`, `SubCode`, `Internal`, `Theory`, `Practical`, `Total`) VALUES
(3, 'electricalengineering', 201, 4, 5, 2, 11),
(3, 'DBMS', 310, 5, 7, 7, 19);

-- --------------------------------------------------------

--
-- Table structure for table `plustwo3`
--

CREATE TABLE IF NOT EXISTS `plustwo3` (
  `RollNo` int(1) DEFAULT NULL,
  `SubName` varchar(15) DEFAULT NULL,
  `SubCode` int(3) DEFAULT NULL,
  `Internal` int(1) DEFAULT NULL,
  `Theory` int(1) DEFAULT NULL,
  `Practical` int(1) DEFAULT NULL,
  `Total` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `plustwo3`
--

INSERT INTO `plustwo3` (`RollNo`, `SubName`, `SubCode`, `Internal`, `Theory`, `Practical`, `Total`) VALUES
(9, 'System Software', 307, 3, 4, 4, 11);

-- --------------------------------------------------------

--
-- Table structure for table `plustwo5`
--

CREATE TABLE IF NOT EXISTS `plustwo5` (
  `RollNo` varchar(10) DEFAULT NULL,
  `SubName` varchar(10) DEFAULT NULL,
  `SubCode` varchar(10) DEFAULT NULL,
  `Internal` varchar(10) DEFAULT NULL,
  `Theory` varchar(10) DEFAULT NULL,
  `Practical` varchar(10) DEFAULT NULL,
  `Total` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sslc1`
--

CREATE TABLE IF NOT EXISTS `sslc1` (
  `RollNo` int(1) DEFAULT NULL,
  `SubName` varchar(21) DEFAULT NULL,
  `SubCode` int(3) DEFAULT NULL,
  `Internal` int(1) DEFAULT NULL,
  `Theory` int(2) DEFAULT NULL,
  `Practical` int(2) DEFAULT NULL,
  `Total` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sslc1`
--

INSERT INTO `sslc1` (`RollNo`, `SubName`, `SubCode`, `Internal`, `Theory`, `Practical`, `Total`) VALUES
(1, 'electricalengineering', 201, 5, 45, 77, 81),
(1, 'Digital Electronics1', 203, 5, 32, 33, 70),
(1, 'English-1', 101, 3, 55, 0, 69),
(1, 'English-2', 102, 3, 77, 0, 80),
(1, 'Maths-1', 103, 6, 44, 0, 50);

-- --------------------------------------------------------

--
-- Table structure for table `sslc2`
--

CREATE TABLE IF NOT EXISTS `sslc2` (
  `RollNo` varchar(10) DEFAULT NULL,
  `SubName` varchar(10) DEFAULT NULL,
  `SubCode` varchar(10) DEFAULT NULL,
  `Internal` varchar(10) DEFAULT NULL,
  `Theory` varchar(10) DEFAULT NULL,
  `Practical` varchar(10) DEFAULT NULL,
  `Total` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sslc3`
--

CREATE TABLE IF NOT EXISTS `sslc3` (
  `RollNo` varchar(10) DEFAULT NULL,
  `SubName` varchar(10) DEFAULT NULL,
  `SubCode` varchar(10) DEFAULT NULL,
  `Internal` varchar(10) DEFAULT NULL,
  `Theory` varchar(10) DEFAULT NULL,
  `Practical` varchar(10) DEFAULT NULL,
  `Total` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sslc4`
--

CREATE TABLE IF NOT EXISTS `sslc4` (
  `RollNo` varchar(10) DEFAULT NULL,
  `SubName` varchar(10) DEFAULT NULL,
  `SubCode` varchar(10) DEFAULT NULL,
  `Internal` varchar(10) DEFAULT NULL,
  `Theory` varchar(10) DEFAULT NULL,
  `Practical` varchar(10) DEFAULT NULL,
  `Total` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sslc4`
--

INSERT INTO `sslc4` (`RollNo`, `SubName`, `SubCode`, `Internal`, `Theory`, `Practical`, `Total`) VALUES
('', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sslc5`
--

CREATE TABLE IF NOT EXISTS `sslc5` (
  `RollNo` varchar(10) DEFAULT NULL,
  `SubName` varchar(10) DEFAULT NULL,
  `SubCode` varchar(10) DEFAULT NULL,
  `Internal` varchar(10) DEFAULT NULL,
  `Theory` varchar(10) DEFAULT NULL,
  `Practical` varchar(10) DEFAULT NULL,
  `Total` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sslc6`
--

CREATE TABLE IF NOT EXISTS `sslc6` (
  `RollNo` varchar(10) DEFAULT NULL,
  `SubName` varchar(10) DEFAULT NULL,
  `SubCode` varchar(10) DEFAULT NULL,
  `Internal` varchar(10) DEFAULT NULL,
  `Theory` varchar(10) DEFAULT NULL,
  `Practical` varchar(10) DEFAULT NULL,
  `Total` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `RollNo` int(1) DEFAULT NULL,
  `SName` varchar(5) DEFAULT NULL,
  `Phno` varchar(16) DEFAULT NULL,
  `Sex` varchar(6) DEFAULT NULL,
  `FName` varchar(7) DEFAULT NULL,
  `Occupation` varchar(8) DEFAULT NULL,
  `MName` varchar(10) DEFAULT NULL,
  `Dob` varchar(16) DEFAULT NULL,
  `Age` int(2) DEFAULT NULL,
  `Caste` varchar(8) DEFAULT NULL,
  `Religion` varchar(23) DEFAULT NULL,
  `Hname` varchar(19) DEFAULT NULL,
  `City` varchar(16) DEFAULT NULL,
  `District` varchar(3) DEFAULT NULL,
  `State` varchar(10) DEFAULT NULL,
  `Pin` int(7) DEFAULT NULL,
  `Year` int(4) DEFAULT NULL,
  `Qualification` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`RollNo`, `SName`, `Phno`, `Sex`, `FName`, `Occupation`, `MName`, `Dob`, `Age`, `Caste`, `Religion`, `Hname`, `City`, `District`, `State`, `Pin`, `Year`, `Qualification`) VALUES
(1, 'Kiran', '334', 'MALE', 'ser', 'fdsf', 'fsdf', '3/3/2004 0:00:00', 5, 'fg', 'gdf', 'hhg', 'gs', 'fsg', 'sfg', 55, 566, 'SSLC'),
(2, 'Sunil', 'sdfsdfsdfsdfwerh', 'FEMALE', 'babusdf', 'sdfsfsdf', '3eeesdfsfs', '2/1/2007 0:00:00', 11, 'sdfsfbnm', 'cathalicsdfsdfbvnvbnbvn', 'HH Viharsdfvbnvbnvn', 'Attingalsdfsvbnb', 'bvn', 'KERALAdsdf', 6951033, 2005, 'SSLC'),
(3, 'Sunil', 'sdfsdfsdfsdfwerh', 'FEMALE', 'babusdf', 'sdfsfsdf', '3eeesdfsfs', '2/1/2007 0:00:00', 11, 'sdfsfbnm', 'cathalicsdfsdfbvnvbnbvn', 'HH Viharsdfvbnvbnvn', 'Attingalsdfsvbnb', 'bvn', 'KERALAdsdf', 6951033, 2005, '+2'),
(5, 'anu', '241575', 'FEMALE', 'kumar', 'eng', 'ammu', '4/5/1986 0:00:00', 18, 'nair', 'hindhu', 'sk bhavan', 'tvm', 'tvm', 'kerala', 695014, 2008, 'SSLC'),
(8, 'Kiran', '334', 'MALE', 'ser', 'fdsf', 'fsdf', '3/3/1986 0:00:00', 5, 'fg', 'gdf', 'hhg', 'gs', 'fsg', 'sfg', 55, 566, '+2'),
(9, 'anu', '241575', 'FEMALE', 'kumar', 'eng', 'ammu', '4/5/1986 0:00:00', 18, 'nair', 'hindhu', 'sk bhavan', 'tvm', 'tvm', 'kerala', 695014, 2008, 'PLUS TWO'),
(0, 'SName', 'Phno', 'Sex', 'FName', 'Occupati', 'MName', 'Dob', 0, 'Caste', 'Religion', 'Hname', 'City', 'Dis', 'State', 0, 0, 'Qualific'),
(1, 'Kiran', '334', 'MALE', 'ser', 'fdsf', 'fsdf', '3/3/2004 0:00:00', 5, 'fg', 'gdf', 'hhg', 'gs', 'fsg', 'sfg', 55, 566, 'SSLC'),
(2, 'Sunil', 'sdfsdfsdfsdfwerh', 'FEMALE', 'babusdf', 'sdfsfsdf', '3eeesdfsfs', '2/1/2007 0:00:00', 11, 'sdfsfbnm', 'cathalicsdfsdfbvnvbnbvn', 'HH Viharsdfvbnvbnvn', 'Attingalsdfsvbnb', 'bvn', 'KERALAdsdf', 6951033, 2005, 'SSLC'),
(3, 'Sunil', 'sdfsdfsdfsdfwerh', 'FEMALE', 'babusdf', 'sdfsfsdf', '3eeesdfsfs', '2/1/2007 0:00:00', 11, 'sdfsfbnm', 'cathalicsdfsdfbvnvbnbvn', 'HH Viharsdfvbnvbnvn', 'Attingalsdfsvbnb', 'bvn', 'KERALAdsdf', 6951033, 2005, '+2'),
(5, 'anu', '241575', 'FEMALE', 'kumar', 'eng', 'ammu', '4/5/1986 0:00:00', 18, 'nair', 'hindhu', 'sk bhavan', 'tvm', 'tvm', 'kerala', 695014, 2008, 'SSLC'),
(8, 'Kiran', '334', 'MALE', 'ser', 'fdsf', 'fsdf', '3/3/1986 0:00:00', 5, 'fg', 'gdf', 'hhg', 'gs', 'fsg', 'sfg', 55, 566, '+2'),
(9, 'anu', '241575', 'FEMALE', 'kumar', 'eng', 'ammu', '4/5/1986 0:00:00', 18, 'nair', 'hindhu', 'sk bhavan', 'tvm', 'tvm', 'kerala', 695014, 2008, 'PLUS TWO');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `Subjectcode` int(3) DEFAULT NULL,
  `Subjectname` varchar(32) DEFAULT NULL,
  `CreditMark` int(1) DEFAULT NULL,
  `MaxMark` int(3) DEFAULT NULL,
  `Type` varchar(12) DEFAULT NULL,
  `Practical` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`Subjectcode`, `Subjectname`, `CreditMark`, `MaxMark`, `Type`, `Practical`) VALUES
(101, 'English-1', 3, 125, 'COUNTING', 'NO'),
(102, 'English-2', 3, 125, 'COUNTING', 'NO'),
(103, 'Maths-1', 5, 150, 'NON COUNTING', 'NO'),
(104, 'maths 2', 6, 125, '', ''),
(105, 'science1', 5, 175, '', ''),
(106, 'science2', 5, 175, '', ''),
(107, 'engineeringgraphics', 3, 125, '', ''),
(108, 'workshoppractice', 3, 125, 'NON COUNTING', ''),
(201, 'electricalengineering', 4, 175, 'COUNTING', 'YES'),
(202, 'basic electronics', 5, 175, 'COUNTING', ''),
(203, 'Digital Electronics1', 5, 175, 'COUNTING', 'YES'),
(204, 'basics of computer system', 5, 175, '', ''),
(205, 'Electronics Circuits1', 4, 175, '', ''),
(206, 'Digital Electronics2', 5, 175, 'COUNTING', ''),
(208, 'Office Automation', 4, 175, '', ''),
(211, 'Microprocessor1', 4, 175, '', ''),
(212, 'Data communication', 3, 125, '', ''),
(213, 'Data Structure with C', 5, 175, '', ''),
(305, 'Humen resource Management system', 5, 125, '', ''),
(306, 'Object oriented programming', 5, 175, '', ''),
(307, 'System Software', 3, 125, '', ''),
(308, 'Computer System Hardware', 6, 175, '', ''),
(309, 'Computer network Protocol', 4, 125, '', ''),
(310, 'DBMS', 5, 175, '', ''),
(311, 'Assembly Language programming', 4, 125, '', ''),
(312, 'Operating system', 4, 125, '', ''),
(313, 'Web programming', 5, 175, '', ''),
(314, 'Microprocessor 2', 5, 175, '', ''),
(391, 'Project&seminar', 6, 200, '', ''),
(401, 'Software engineering', 4, 125, '', ''),
(402, 'Active Server Pages', 4, 125, 'COUNTING', 'NO'),
(403, 'Computer Graphics', 4, 125, '', ''),
(417, 'Micro controller', 4, 125, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `uad`
--

CREATE TABLE IF NOT EXISTS `uad` (
  `Username` varchar(5) DEFAULT NULL,
  `Password` varchar(4) DEFAULT NULL,
  `Type` varchar(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uad`
--

INSERT INTO `uad` (`Username`, `Password`, `Type`) VALUES
('admin', 'pass', 'admin'),
('anil', 'pass', 'Student'),
('beena', 'ce', 'Admin'),
('sonu', 'test', 'Admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
